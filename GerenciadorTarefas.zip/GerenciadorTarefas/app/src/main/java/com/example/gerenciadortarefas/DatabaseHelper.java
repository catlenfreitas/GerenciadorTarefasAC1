package com.example.gerenciadortarefas;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tarefas.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "tarefas";
    public static final String COL_ID = "id";
    public static final String COL_TITULO = "titulo";
    public static final String COL_DISCIPLINA = "disciplina";
    public static final String COL_DATA = "data";
    public static final String COL_PRIORIDADE = "prioridade";
    public static final String COL_DESCRICAO = "descricao";
    public static final String COL_CONCLUIDA = "concluida";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_TITULO + " TEXT, " +
                COL_DISCIPLINA + " TEXT, " +
                COL_DATA + " TEXT, " +
                COL_PRIORIDADE + " TEXT, " +
                COL_DESCRICAO + " TEXT, " +
                COL_CONCLUIDA + " INTEGER)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Método para inserir tarefa
    public boolean inserirTarefa(String titulo, String disciplina, String data,
                                 String prioridade, String descricao, boolean concluida) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_TITULO, titulo);
        values.put(COL_DISCIPLINA, disciplina);
        values.put(COL_DATA, data);
        values.put(COL_PRIORIDADE, prioridade);
        values.put(COL_DESCRICAO, descricao);
        values.put(COL_CONCLUIDA, concluida ? 1 : 0);

        long result = db.insert(TABLE_NAME, null, values);

        return result != -1;
    }
}