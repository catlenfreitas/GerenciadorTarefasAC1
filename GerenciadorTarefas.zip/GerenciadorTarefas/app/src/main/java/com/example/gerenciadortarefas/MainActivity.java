package com.example.gerenciadortarefas;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;

    EditText etTitulo, etDisciplina, etData, etDescricao;
    Spinner spPrioridade;
    CheckBox cbConcluida;
    Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DatabaseHelper(this);

        etTitulo = findViewById(R.id.etTitulo);
        etDisciplina = findViewById(R.id.etDisciplina);
        etData = findViewById(R.id.etData);
        etDescricao = findViewById(R.id.etDescricao);
        spPrioridade = findViewById(R.id.spPrioridade);
        cbConcluida = findViewById(R.id.cbConcluida);
        btnSalvar = findViewById(R.id.btnSalvar);

        // Spinner simples
        String[] prioridades = {"Baixa", "Média", "Alta"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, prioridades);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spPrioridade.setAdapter(adapter);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String titulo = etTitulo.getText().toString();
                String disciplina = etDisciplina.getText().toString();
                String data = etData.getText().toString();
                String descricao = etDescricao.getText().toString();
                String prioridade = spPrioridade.getSelectedItem().toString();
                boolean concluida = cbConcluida.isChecked();

                String mensagem = "Tarefa salva:\n"
                        + "Título: " + titulo + "\n"
                        + "Disciplina: " + disciplina + "\n"
                        + "Data: " + data + "\n"
                        + "Prioridade: " + prioridade + "\n"
                        + "Concluída: " + (concluida ? "Sim" : "Não");

                Toast.makeText(MainActivity.this, mensagem, Toast.LENGTH_LONG).show();
            }
        });
    }
}